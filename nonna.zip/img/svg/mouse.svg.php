<div class="mouse">
    <div class="mouse__wrapper">
        <div class="mouse__scroll"></div>
    </div>
</div>