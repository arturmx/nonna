<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="28px" height="16px">
  <path fill-rule="evenodd" fill="rgb(0, 0, 0)" d="M7.679,-0.001 L8.926,1.298 L3.376,7.081 L28.000,7.081 L28.000,8.918 L3.376,8.918 L8.926,14.700 L7.679,15.999 L-0.000,7.999 L7.679,-0.001 Z" />
</svg>