<section class="lightbox">
  <div class="lightbox__wrapper">
    <div class="lightbox__arrow lightbox__arrow--close"><?php get_template_part('./img/svg/close.svg'); ?></div>
    <div class="lightbox__img-wrapper">
      <div class="lightbox__arrow lightbox__arrow--prev"><?php get_template_part('img/svg/arrow.svg'); ?></div>
      <div class="lightbox__img" ><img src="" /></div>
      <div class="lightbox__arrow lightbox__arrow--next"><?php get_template_part('img/svg/arrow.svg'); ?></div>
    </div>
  </div>
</section>