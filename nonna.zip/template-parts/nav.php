<ul class="nav">
  <li class="nav__item nav__item--home"><a class="nav__link" href="#home">home</a></li>
  <li class="nav__item"><a class="nav__link" href="#o-nas"><?php pll_e('o nas') ?></a></li>
  <li class="nav__item"><a class="nav__link" href="#menu">menu</a></li>
  <li class="nav__item"><a class="nav__link" href="#kontakt"><?php pll_e('kontakt') ?></a></li>
</ul>