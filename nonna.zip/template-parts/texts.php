<section class="texts" id="o-nas">
  <div class="container">
    <div class="texts__wrapper">
      <div class="texts__column">
        <h2 class="texts__heading"><?php the_field('texts_naglowek'); ?></h2>
      </div>
      <div class="texts__column">
        <div class="texts__text"><?php the_field('texts_text'); ?></div>
      </div>
    </div>
  </div>
</section>